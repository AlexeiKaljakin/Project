package settings;

import java.util.Map;

public interface ISettings {
    Map<String, String> read();
}
